import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { UIModule } from '@/ui/UIModule'

describe('UIModule', () => {

    beforeEach(() => {
        global.fetch = vi.fn()
    })

    it('shouldShowAdapterList', async () => {
        vi.mocked(fetch).mockResolvedValueOnce({
            json: async () => [
                { name: 'webUI', active: false },
                { name: 'desktopUI', active: false },
            ],
        } as Response)

        render(<UIModule />)

        await waitFor(() => {
            expect(screen.getByText('webUI')).toBeInTheDocument()
            expect(screen.getByText('desktopUI')).toBeInTheDocument()
        })
    })

    it('shouldSendActivateRequestWhenOpenButtonClicked', async () => {
        vi.mocked(fetch)
            .mockResolvedValueOnce({
                json: async () => [
                    { name: 'webUI', active: false },
                    { name: 'desktopUI', active: false },
                ],
            } as Response)
            .mockResolvedValueOnce({} as Response)
            .mockResolvedValueOnce({
                json: async () => [
                    { name: 'webUI', active: true },
                    { name: 'desktopUI', active: false },
                ],
            } as Response)

        render(<UIModule />)

        await waitFor(() => screen.getByText('webUI'))
        await userEvent.click(screen.getByRole('button', { name: /avaa webUI/i }))

        expect(fetch).toHaveBeenCalledWith(
            'http://localhost:8080/api/ui/adapters/webUI/activate',
            expect.objectContaining({ method: 'POST' })
        )
    })

    it('shouldSendCloseRequestWhenCloseButtonClicked', async () => {
        vi.mocked(fetch)
            .mockResolvedValueOnce({
                json: async () => [
                    { name: 'webUI', active: true },
                    { name: 'desktopUI', active: false },
                ],
            } as Response)
            .mockResolvedValueOnce({} as Response)
            .mockResolvedValueOnce({
                json: async () => [
                    { name: 'webUI', active: false },
                    { name: 'desktopUI', active: false },
                ],
            } as Response)

        render(<UIModule />)

        await waitFor(() => screen.getByText('webUI'))
        await userEvent.click(screen.getByRole('button', { name: /sulje webUI/i }))

        expect(fetch).toHaveBeenCalledWith(
            'http://localhost:8080/api/ui/adapters/webUI/close',
            expect.objectContaining({ method: 'POST' })
        )
    })

    it('shouldShowErrorMessageWhenFetchFails', async () => {
        vi.mocked(fetch).mockRejectedValueOnce(new Error('Network error'))

        render(<UIModule />)

        await waitFor(() => {
            expect(screen.getByText('Yhteys palvelimeen epäonnistui')).toBeInTheDocument()
        })
    })
})